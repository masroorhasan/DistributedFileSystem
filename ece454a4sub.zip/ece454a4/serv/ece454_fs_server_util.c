#include "ece454_fs_server.h"

/*
 * Creates a directory stream using the folder name
 * passed in on server launch.
 */
extern void setHostFolder(char* folder_name) {
    hosted_folder_name = folder_name;
}

/*
 * Initializes directory entries structure, dir_entries.
 */
extern void initDirEntries() {
		next_dir_entry = 0;

		int i = 0;
		for (; i < 256; i++) {
				dir_entries[i] = (DIR *)malloc(SIZE_DIR);
		}
}

/*
 * Removes local folder name prefix and returns the true
 * folder path.
 */
extern char* parseFolderPath(const char* folderPath) {
    char* servFolderPath;
    return servFolderPath;
}

